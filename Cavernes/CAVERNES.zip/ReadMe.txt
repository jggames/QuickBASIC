"Cavernes dans le poquette" by Charles Feydy (1982)

The Caverns in My Pocket/Des Cavernes dans le poquette by Charles Feydy
1982. English translation from French and port to the MS Quick Basic. From TRACE magazine Issue 2 - 2nd quarter 1982, p. 62. This is an update to a port I made recently. I had to switch do a BASIC with Double precision to overcome a limitation in Micro Color BASIC exponent function and its decimal precision to get the game to work properly. It was originally for the TRS-80 Pocket Computer1.

Jim Gerrie
Sydney, NS Canada
2024
